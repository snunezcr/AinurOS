
Clean (::ComplexInt:==(Int,Int))